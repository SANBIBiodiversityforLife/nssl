<?php
/**
 * @file
 * Contains \Drupal\ssp_import\Controller\SspImportController.
 */
namespace Drupal\ssp_import\Controller;
class SspImportController {
  public function content() {
    return array(
      '#type' => 'markup',
      '#markup' => t('Hello, World!'),
    );
  }
}